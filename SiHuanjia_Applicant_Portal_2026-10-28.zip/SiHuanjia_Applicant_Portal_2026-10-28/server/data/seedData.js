import { normaliseJobStorage } from "./jobOptions.js";

const startAvailabilityOptions = [
  "Immediately",
  "Within 2 weeks",
  "Within 1 month",
  "Within 2 months",
  "More than 2 months",
];

export const demoJobs = [
  {
    id: 1,
    title: "Senior Software Engineer",
    department: "Engineering",
    location: "Singapore",
    workMode: "Hybrid",
    employmentType: "Full-time",
    experienceLevel: "3-5 years",
    salaryRange: "SGD 7,000-9,000 per month",
    summary: "Build reliable recruitment products and mentor engineers in a collaborative product team.",
    responsibilities: [
      "Design and develop maintainable web applications using JavaScript and React.",
      "Build REST APIs and work with product, design, and quality assurance colleagues.",
      "Review code, improve engineering standards, and support less experienced developers.",
      "Investigate production issues and improve performance, security, and accessibility.",
    ],
    requirements: [
      "Degree or equivalent experience in software engineering or a related field.",
      "At least three years of professional web development experience.",
      "Strong JavaScript, React, HTML, CSS, and REST API knowledge.",
      "Able to work in Singapore using a hybrid schedule.",
    ],
    preferredQualifications: [
      "Experience with Node.js, Express, MySQL, or Sequelize.",
      "Experience writing automated tests and working with Git-based code review.",
      "Clear written communication and experience collaborating across disciplines.",
    ],
    benefits: [
      "Two technical interviews followed by a team discussion.",
      "Flexible hybrid working, learning allowance, and private medical coverage.",
      "Expected hiring decision within two weeks of the final interview.",
    ],
    roleQuestions: [
      { id: "availability", label: "When could you start this role?", type: "select", options: startAvailabilityOptions, maxLength: 40, required: true },
      { id: "technical_project", label: "Describe one software project that best demonstrates your suitability.", type: "long", maxLength: 600, required: true, placeholder: "Explain your responsibility, technical decisions, and measurable result." },
      { id: "work_authorisation", label: "Do you currently have the right to work in Singapore?", type: "select", options: ["Yes", "No", "I require sponsorship"], maxLength: 40, required: true },
    ],
    closingDate: "2026-12-15",
    isOpen: true,
  },
  {
    id: 2,
    title: "Product Analyst",
    department: "Product",
    location: "Singapore",
    workMode: "On-site",
    employmentType: "Full-time",
    experienceLevel: "1-3 years",
    salaryRange: "SGD 4,800-6,300 per month",
    summary: "Turn customer and product data into clear recommendations for the company's digital services.",
    responsibilities: [
      "Analyse product behaviour, customer feedback, and operational performance.",
      "Create reports and explain findings to product and engineering teams.",
      "Define success measures for new features and support experiment design.",
    ],
    requirements: [
      "Degree in business analytics, information systems, statistics, or a related field.",
      "One to three years of analytical or product experience.",
      "Confident using spreadsheets, SQL, and data visualisation tools.",
      "Able to communicate findings clearly to technical and non-technical colleagues.",
    ],
    preferredQualifications: [
      "Experience with web analytics or product experimentation.",
      "Basic understanding of recruitment or human resources processes.",
    ],
    benefits: [
      "Practical case exercise followed by a panel interview.",
      "Professional development budget and flexible working hours.",
    ],
    roleQuestions: [
      { id: "availability", label: "When could you start this role?", type: "select", options: startAvailabilityOptions, maxLength: 40, required: true },
      { id: "analysis_example", label: "Give an example of a recommendation you made using data.", type: "long", maxLength: 600, required: true, placeholder: "Describe the data, your analysis, recommendation, and outcome." },
      { id: "sql_level", label: "How would you describe your SQL skill level?", type: "select", options: ["Basic", "Intermediate", "Advanced"], maxLength: 40, required: true },
    ],
    closingDate: "2026-11-30",
    isOpen: true,
  },
  {
    id: 3,
    title: "UX Designer",
    department: "Design",
    location: "Singapore",
    workMode: "Hybrid",
    employmentType: "Full-time",
    experienceLevel: "1-3 years",
    salaryRange: "SGD 5,200-7,200 per month",
    summary: "Design simple, accessible recruitment experiences for applicants and hiring teams.",
    responsibilities: [
      "Plan user research and translate findings into clear interface improvements.",
      "Create user flows, wireframes, prototypes, and design specifications.",
      "Work closely with developers to review implementation quality.",
    ],
    requirements: [
      "Portfolio showing end-to-end digital product design work.",
      "At least two years of UX or product design experience.",
      "Strong Figma, prototyping, information architecture, and usability testing skills.",
      "Good understanding of responsive and accessible web design.",
    ],
    preferredQualifications: [
      "Experience designing HR, recruitment, or business software.",
      "Working knowledge of HTML and CSS.",
    ],
    benefits: [
      "Portfolio review, design exercise, and final team interview.",
      "Flexible hybrid work and annual design conference allowance.",
    ],
    roleQuestions: [
      { id: "portfolio", label: "Provide your portfolio link and access password if required.", type: "short", maxLength: 240, required: true, placeholder: "https://..." },
      { id: "design_case", label: "Which portfolio project is most relevant to this role, and why?", type: "long", maxLength: 600, required: true, placeholder: "Describe the problem, your contribution, and the result." },
      { id: "availability", label: "When could you start this role?", type: "select", options: startAvailabilityOptions, maxLength: 40, required: true },
    ],
    closingDate: "2026-12-05",
    isOpen: true,
  },
  {
    id: 4,
    title: "Quality Assurance Engineer",
    department: "Engineering",
    location: "Singapore",
    workMode: "Remote",
    employmentType: "Full-time",
    experienceLevel: "1-3 years",
    salaryRange: "SGD 4,800-6,500 per month",
    summary: "Improve release confidence through thoughtful manual and automated testing.",
    responsibilities: [
      "Create test plans from product requirements and user journeys.",
      "Perform exploratory, regression, API, and browser compatibility testing.",
      "Build maintainable automated tests and report defects clearly.",
    ],
    requirements: [
      "At least one year of software quality assurance experience.",
      "Experience testing web applications and REST APIs.",
      "Able to write clear reproduction steps and collaborate with developers.",
      "Comfortable working independently in a remote environment.",
    ],
    preferredQualifications: [
      "Experience with Playwright, Cypress, Postman, or JavaScript.",
      "Basic knowledge of continuous integration pipelines.",
    ],
    benefits: [
      "Technical interview and practical testing exercise.",
      "Remote equipment allowance and structured learning time.",
    ],
    roleQuestions: [
      { id: "testing_example", label: "Describe a difficult defect you found and how you investigated it.", type: "long", maxLength: 600, required: true, placeholder: "Explain the context, investigation, and outcome." },
      { id: "automation_tool", label: "Which test automation tool have you used most?", type: "short", maxLength: 120, required: true, placeholder: "Example: Playwright with JavaScript." },
      { id: "remote_setup", label: "Are you able to work remotely from Singapore?", type: "select", options: ["Yes", "No"], maxLength: 20, required: true },
    ],
    closingDate: "2026-12-20",
    isOpen: true,
  },
].map(normaliseJobStorage);

export const demoProfile = {
  phone: "+65 8123 4567",
  location: "Singapore",
  availabilityStatus: "AVAILABLE",
  education: [
    {
      institution: "University of Newcastle",
      qualification: "Bachelor of Information Technology",
      qualificationLevel: "BACHELOR",
      startYear: "2024",
      graduationYear: "2026",
    },
  ],
  languages: [
    { language: "English", readingLevel: "Advanced", writingLevel: "Advanced" },
    { language: "Chinese", readingLevel: "Native", writingLevel: "Native" },
  ],
};
